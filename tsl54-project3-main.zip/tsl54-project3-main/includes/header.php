<head>
  <meta charset="UTF-8" />
  <title> Sunday School Lesson Swaps</title>
  <link rel="stylesheet" type="text/css" href="/public/styles/site.css" media="all" />
</head>

<body>
  <nav>
    <ul>
        <li id="logo"><a href="/"><img src="public/images/logo.png" alt="logo"></a></li>
          <?php
      if (is_user_logged_in() && $is_admin) { ?>
        <li id="login-nav"><a href="<?php echo logout_url(); ?>">Sign Out</a></li>
        <?php }
      else { ?>
        <li id="login-nav"><a href="/login">Log In</a> </li>
        <?php } ?>
    </ul>
  </nav>
