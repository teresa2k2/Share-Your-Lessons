<footer>
    <h3>made with ❤️ Teresa Lian </h3>
</footer>
