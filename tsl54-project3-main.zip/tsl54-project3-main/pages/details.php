<?php

$get_id = ($_GET['record'] == '' ? NULL : (int)$_GET['record']);

if ($get_id != NULL) {
    $content_result = exec_sql_query(
      $db,
      "SELECT * FROM contents
       WHERE contents.id = :content_id;",
      array(':content_id' => $get_id)
    );
    $record = $content_result->fetchAll()[0];


    $tag_result = exec_sql_query(
      $db,
      "SELECT * FROM tags
       INNER JOIN content_tags ON tags.id = content_tags.tag_id
       WHERE content_tags.content_id = :content_id;",
      array(':content_id' => $get_id)
    );
    $tag_records = $tag_result->fetchAll();

    $image_url = 'public/uploads/contents/' . $record['id'] . '.' . $record['image_ext'];

}
?>

<!DOCTYPE html>
<html lang="en">

    <?php include 'includes/header.php'; ?>

    <main  class="detail-main">

      <?php if ($get_id != NULL) { ?>
        <form action="/details?<?php echo http_build_query(array('record' => $get_id)); ?>" method="post" enctype="multipart/form-data" >
          <input type="hidden" name="record" value="<?php echo $get_id; ?>">

          <div class="detail-contents">

            <img src="<?php echo htmlspecialchars($image_url); ?>" alt="<?php echo htmlspecialchars($record['cover_image']); ?>">

            <div class="detail-texts">
              <h1><?php echo htmlspecialchars($record['title']); ?></h1>
              <h5>Cover Image Source:</h5>
                  <p><a href="<?php echo htmlspecialchars($record['image_source']); ?>">
                  <?php echo htmlspecialchars($record['image_source']); ?></a></p>
              <h5>Tags:</h5>
                  <?php foreach ($tag_records as $tag_record) { ?>
                    <p class="tagslabel"> <?php echo htmlspecialchars($tag_record['tag_name']); ?></p>
                    <?php } ?>
              <h5>Description:</h5>
                <p> <?php echo htmlspecialchars($record['describe']); ?></p>
              <h5>Link to Slides:</h5>
                  <p><a href="<?php echo htmlspecialchars($record['slide_link']); ?>">
                  <?php echo htmlspecialchars($record['slide_link']); ?></a></p>
              <h5>Accompanying Activities:</h5>
                  <p><a href="<?php echo htmlspecialchars($record['activity_link']); ?>">
                  <?php echo htmlspecialchars($record['activity_link']); ?></a></p>
              <h5>Uploaded by:</h5>
                  <p><?php echo htmlspecialchars($record['author']); ?></p>
              <h5>Upload Date:</h5>
                  <p><?php echo htmlspecialchars($record['upload_date']); ?></p>
            </div>
          </div>
        </form>
      <?php } ?>
    </main>
  </body>

</html>
