
<!DOCTYPE html>
<html lang="en">

  <?php include 'includes/header.php'; ?>

  <main class="form-main">
    <div class="all-form">

    <?php
      if (is_user_logged_in() && $is_admin) { ?>
        <p>Welcome<?php echo htmlspecialchars($current_user['name']);
    ?>!</p>
    <?php } else { echo login_form('/form', $session_messages);} ?>

  </main>
</body>
</html>
