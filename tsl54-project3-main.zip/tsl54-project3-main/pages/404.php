<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Lesson Swaps</title>
  <link rel="stylesheet" type="text/css" href="/public/styles/site.css" media="all">
</head>

<body>

<?php include 'includes/header.php'; ?>

<main class="bad-main">

<div class="bad">
<h1>404!</h1>

<h2> Whoops, it seems that the page you are looking for does not exist! Please check your URL and try again!</h2>

</div>


</main>



</body>

</html>

</body>

</html>
