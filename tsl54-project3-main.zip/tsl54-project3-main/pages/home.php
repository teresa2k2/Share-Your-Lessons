<?php
$records = [];

$query = "SELECT * FROM contents
ORDER BY contents.id desc;";
$result = $db->query($query);
$records = $result->fetchAll();

foreach ($records as $record) {
  if (isset($_POST['delete' . $record[0]])) {
    $image_url = "public/uploads/contents/" . $record['cover_image'];
    exec_sql_query(
      $db,
      "DELETE FROM content_tags
       WHERE content_id = :id",
      array(':id' => $record[0])
    );
//source for line 14-16: https://www.w3schools.com/sql/sql_delete.asp

    exec_sql_query(
      $db,
      "DELETE FROM contents
       WHERE id = :id",
      array(':id' => $record[0])
    );
//source for line 22-23: https://www.w3schools.com/sql/sql_delete.asp


    unlink($image_url);
    header("location: /");
//source for line 29: https://www.php.net/manual/en/function.delete.php#:~:text=There%20is%20no%20delete%20keyword,scope%2C%20check%20out%20unset().
//source for line 30: https://www.php.net/manual/en/function.header.php
  }
}



if (isset($_GET["tag"])) {
  $filter_tag = $_GET["tag"];
  if ($filter_tag == "") {
    $query = "SELECT * FROM contents";
    $result = $db->query($query);
    $records = $result->fetchAll();
  } else {
    $filter_result = exec_sql_query(
      $db,
      "SELECT * FROM contents
      INNER JOIN content_tags ON contents.tag_id = content_tags.content_id
      INNER JOIN tags ON content_tags.tag_id = tags.id
      WHERE tags.tag_name = :tag_name
      ORDER BY contents.id desc;",
      array(
        ":tag_name" => $filter_tag
      )
    );

    $records = $filter_result->fetchAll();
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<?php require_once 'includes/header.php'; ?>



<div class="all-header">
  <div class="top">
    <h1>CREATE & SWAP</h1>
    <h2>SHARE HIS MESSAGE</h2>
    <h3>Elevate your Sunday School lessons with shared resources from a collaborative community of teachers</h3>
    <a href="/form">SHARE MY LESSONS</a>
  </div>
    <picture><img src="public/images/landing.png" alt="landing-image"></picture>
    <!-- landing-image source: https://www.pngwing.com/en/free-png-prlig -->
</div>


<form method="get">
  <div class="filter-button">
    <h3 class="filter-title">Filter by Tag</h3>
      <?php
        if (count($records) > 0) {
          $tags = $db->query("SELECT tag_name FROM tags")->fetchAll();
          foreach ($tags as $tag) {
            echo
            '<label>
               <input type="radio" name="tag" value="' . htmlspecialchars($tag['tag_name']) . '"> ' . htmlspecialchars($tag['tag_name']) .
            '</label>';
          }
        }
      ?>
  </div>
      <input id="filter-tag-button" type="submit" value="view all" />
      <input id="view-all-button" type="submit" value="filter tag" />

</form>


<main>

  <ul>
    <?php foreach ($records as $record) {
      $image_url = 'public/uploads/contents/' . $record['cover_image'];
      $details_url = '/details?record=' . $record[0];
    ?>

    <li>
      <?php
          if (is_user_logged_in() && $is_admin) { ?>
            <form method="post" action="/" novalidate>
            <input class="delete-button" type="submit" name="<?php echo "delete" . $record[0] ?>" value="X" /> </form>
          <?php } else { ?>

          <?php } ?>

          <a href="<?php echo htmlspecialchars($details_url); ?>" class="images-button">
            <img src="<?php echo htmlspecialchars($image_url); ?>" alt="<?php echo htmlspecialchars($record['cover_image']); ?>">
          </a>
          <p class="title"><?php echo htmlspecialchars($record['title']); ?></p>
          <p><?php echo htmlspecialchars($record['author']); ?></p>
          <p class="source-title">Image Source:</p>
          <p class="image-source"><a href="<?php echo htmlspecialchars($record['image_source']); ?>">
          <?php echo htmlspecialchars($record['image_source']); ?></a></p>
    </li>
       <?php } ?>
  </ul>

    </main>

    <?php include 'includes/footer.php'; ?>

</body>

</html>
