<?php


define("MAX_FILE_SIZE", 10000000);

$upload_cover_image = NULL;
$upload_image_ext = NULL;
$cover_link = NULL;
$title = Null;
$tags = NULL;
$author = NULL;
$describe = NULL;
$slide_link = NULL;
$activity_link = NULL;
$upload_date = NULL;


if (isset($_POST["upload"])) {


  $form_valid = True;
  $upload = $_FILES['png_file'];

  if ($upload['error'] == UPLOAD_ERR_OK) {
    $upload_cover_image = basename($upload['name']);
    $upload_image_ext = strtolower(pathinfo($upload_cover_image, PATHINFO_EXTENSION));
  }

  $title = trim($_POST["upload-title"]);
  $cover_link = trim($_POST["cover-image-source"]);
  $author = trim($_POST["created-by"]);
  $describe = trim($_POST["upload-des"]);
  $slide_link = trim($_POST["slides"]);
  $activity_link = trim($_POST["activities"]);
  $upload_date = date("m-d-Y");

  if ($form_valid) {

    $result = exec_sql_query(
      $db,
      "INSERT INTO contents
          (cover_image, tag_id, image_ext, image_source, title, author, describe, slide_link, activity_link, upload_date)
        VALUES
          (:cover_image, :tag_id, :image_ext, :image_source, :title, :author, :describe, :slide_link, :activity_link, :upload_date)",
      array(
        ':cover_image' => 0 . '.png',
        ':tag_id' => 0,
        ':image_ext' => $upload_image_ext,
        ':image_source' => $cover_link,
        ':title' => $title,
        ':author' => $author,
        ':describe' => $describe,
        ':slide_link' => $slide_link,
        ':activity_link' => $activity_link,
        ':upload_date' => $upload_date
      )
    );
    if ($result) {
      $record_id = $db->lastInsertId('id');
      $upload_storage_path = 'public/uploads/contents/' . $record_id . '.png';
      if (move_uploaded_file($upload["tmp_name"], $upload_storage_path) == false) {
        error_log("Folder not found");
      }

      exec_sql_query(
        $db,
        "UPDATE contents SET tag_id = :tag_id, cover_image = :cover_img WHERE id = :id",
        array(":tag_id" => $record_id, ":cover_img" => "" . $record_id . ".png", ":id" => $record_id)
      );
//source for line 74: https://www.w3schools.com/sql/sql_update.asp

      $tag_result = exec_sql_query(
        $db,
        "SELECT * FROM tags",
        array()
      );
      $tag_result = $tag_result->fetchAll();
      foreach ($tag_result as $tag) {
        if (isset($_POST[$tag[1]])) {
          exec_sql_query(
            $db,
            "INSERT INTO content_tags (content_id, tag_id)
             VALUES (:content_id, :tag_id)",
            array(
              ":content_id" => $record_id,
              ":tag_id" => $tag['id'],
            )
          );
        }
      }
      header("Location: /");
      exit;
 //source for line 98-99: https://www.php.net/manual/en/function.header.php
    }
  }
}

?>


<!DOCTYPE html>
<html lang="en">


  <?php include 'includes/header.php'; ?>

  <main class="form-main">
    <div class="all-form">

      <?php
      if (is_user_logged_in() && $is_admin) { ?>

        <h1 class="second"> Share your lessons! </h1>
        <form method="post" enctype="multipart/form-data">
          <div class="form">

            <label> Title:
              <br>
              <input type="text" class="form-input" id="upload-title" name="upload-title" required />
            </label>


            <label>Upload Cover Image:
              <br>
              <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo MAX_FILE_SIZE; ?>">
              <input id="upload-button" type="file" name="png_file" accept=".png,image/png" required>
            </label>

            <label>Cover Image Source:
              <br>
              <input type="text" class="form-input" id="cover-image-source" name="cover-image-source" required />
            </label>


            <p>Tags:</p>
              <?php
              $tags = $db->query("SELECT tag_name FROM tags WHERE id!=5")->fetchAll();
              foreach ($tags as $tag) {
                echo '
                   <input type="checkbox" name="' . htmlspecialchars($tag['tag_name']) . '" value="' . htmlspecialchars($tag['tag_name']) . '"> ' . htmlspecialchars($tag['tag_name']) .'';
              }
              ?>


            <label> Description:
              <br>
              <input type="text" class="form-input" id="upload-des" name="upload-des" required />
            </label>

            <label> Links to Slides:
              <br>
              <input type="text" class="form-input" id="slides" name="slides" required />
            </label>

            <label> Links to Activities:
              <br>
              <input type="text" class="form-input" id="activities" name="activities" required />
            </label>

            <label> Created-by:
              <br>
              <input type="text" class="form-input" id="created-by" name="created-by" required />
            </label>

            <button class="form-input" id="upload" name="upload" type="submit">Upload</button>

          </div>
          </form>
          </div>



        <?php } else { echo login_form('/form', $session_messages);} ?>



  </main>
</body>

</html>
