CREATE TABLE users (
  id INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT)
);

INSERT INTO
  users (id, name, email, username, password)
VALUES
  (
    1,
    'Anna',
    'anna@gmail.com',
    'anna',
    '$2y$10$QtCybkpkzh7x5VN11APHned4J8fu78.eFXlyAMmahuAaNcbwZ7FH.'
  );

CREATE TABLE sessions (
  id INTEGER NOT NULL UNIQUE,
  user_id INTEGER NOT NULL,
  session TEXT NOT NULL UNIQUE,
  last_login TEXT NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT) FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE groups (
  id INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE,
  PRIMARY KEY(id AUTOINCREMENT)
);

INSERT INTO
  groups (id, name)
VALUES
  (1, 'admin');

CREATE TABLE user_groups (
  id INTEGER NOT NULL UNIQUE,
  user_id INTEGER NOT NULL,
  group_id INTEGER NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT) FOREIGN KEY(group_id) REFERENCES groups(id),
  FOREIGN KEY(user_id) REFERENCES users(id)
);

INSERT INTO
  user_groups (user_id, group_id)
VALUES
  (1, 1);



--- Data Source: https://www.biblestudytools.com/sunday-school-lessons/  ---
CREATE TABLE contents (
  id INTEGER NOT NULL UNIQUE,
  tag_id INTEGER,
  cover_image TEXT NOT NULL,
  image_ext TEXT NOT NULL,
  image_source TEXT NOT NULL,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  describe TEXT NOT NULL,
  slide_link TEXT NOT NULL,
  activity_link TEXT NOT NULL,
  upload_date TEXT NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT) FOREIGN KEY (tag_id) REFERENCES tags(id)
);

INSERT INTO
  contents (id, tag_id, cover_image, image_ext, image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
1,
1,
'1.png',
'png',
'https://www.behance.net/gallery/153712189/Fruit-of-the-Spirit',
'Fruit of the Spirit',
"Children's Ministry Deals",
'Kids will learn about the Fruit of the Spirit and why they are important.',
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'01-20-2012');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext, image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
2,
2,
'2.png',
'png',
'crosswayfellowship.org/kids-resources/u1-lesson1',
'Creation',
"Children's Ministry Deals",
'Kids will learn that they were created by God.',
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'04-20-2012');

INSERT INTO
  contents (id, tag_id, cover_image,image_ext,image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
3,
3,
'3.png',
'png',
'http://www.leonardolovari.com/the-ten-commandments-and-the-book-of-the-dead/?doing_wp_cron=1681506012.4342310428619384765625',
'The 10 Commandments',
"Children's Ministry Deals",
'God wanted his people Israel to live as sweet a life as possible, so he gave them 10 commandments for being “sweet” to him and “sweet” to others.',
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'01-30-2022');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext, image_source, title,  author, describe, slide_link, activity_link, upload_date)
VALUES (
4,
4,
'4.png',
'png',
'https://www.istockphoto.com/vector/cartoon-noahs-ark-gm506181658-84091999',
'Noah and the Big Flood',
"Children's Ministry Deals",
'Kids will learn that it’s important that we don’t let other people’s opinions sway us from obeying God.',
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'01-10-2018');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext, image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
5,
5,
'5.png',
'png',
'https://www.freepik.com/premium-vector/bible-narratives-about-david-goliath-christian-bible-character-scripture-history-david-goliath-middle-battle-illustration_10275407.htm',
'Strength in God',
'Dr.Jerald Daffe',
"In the books of Kings and Chronicles, similar accounts of the same events, we encounter a new period in the history of Israel—the era of the monarchy. The beginnings of this era are rocky at best. Saul, the impressive first king of Israel, loses his life in battle while David rises to power. David almost loses the throne to one rebellious son only to have it reach its cultural height in another. Just after Solomon's death, however, the cycle that we quickly get used to in these books begins. That is, Israel is led by a mixed bag of kings. Some follow Yahweh. Others do not. However, there are also plenty of in-between kings. We will see in the reign of Asa that Israel's kings were complex personalities who often vacillated in their commitment to God and in their administrative and military competence. Only through God's mercy could such leaders continue to lead Israel through its struggles as a people.",

'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'09-10-2012');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext,image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
6,
6,
'6.png',
'png',
'https://bibleteachingnotes.blog/2019/04/24/2-kings-20/',
'Hezekiah - Spiritual Renewal',
'Dr. Jerald Daffe',
'Spiritual renewal is often associated with the present concept of "revival." It was in the nineteenth century that Cotton Mather first used the word to describe a great awakening in the early Americas. The word derives from the Latin revivere, "to live again," and was typically used to describe an old play that was brought back to a new generation of theater audiences. The concept is closest to the Old Testament idea of renewal or restoration, found especially in the work of leaders such as Hezekiah and Josiah.',
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'01-20-2012');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext,image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
7,
7,
'7.png',
'png',
'https://www.123rf.com/stock-photo/jesus_love.html',
'Christ in You',
'R. Keith Whitt',
'Remember the television reality program titled Extreme Makeover? Each week two individuals were selected to undergo a number of procedures which would improve their appearance, self-image, and personal life. Over a period of several months they would have plastic surgery, major dental work, hair restyling, and be given a new wardrobe. Then there would be a celebratory revealing of the new person to their family and friends. Tears, hugs, smiles, applause, and varied exclamations were evident as the person displayed his or her new self.',
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'03-20-2019');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext,image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
8,
8,
'8.png',
'png',
'https://www.freepik.com/premium-vector',
'Faith to Believe and Intercede',
'Josh Rice',
'At the heart of a vibrant, healthy faith is basic communication. God calls us to the essential task of being in ongoing interaction with Him. In fact, the primary means by which any relationship is established and maintained is simple conversation. Relationships are grown through hours of talking.',
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'05-20-2022');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext,image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
9,
9,
'9.png',
'png',
'https://www.freepik.com/free-photos-vectors/bible-cartoon',
'Josiah - Rediscovering the Word',
'Dr. Jerald Daffe',
"In the story of King Josiah we discover a time period in which the nation of Judah has forgotten the Scriptures. Sadly, many nations in our world today live in similar shambles. To cite one example, according to a 2004 Barna Research Group study, only 4 percent of American adults have what can be considered a 'biblical worldview,' which simply refers to a way of seeing life according to the truths of Scripture. Such ignorance of God's Word is not without grave consequences, as seen in many corners of our culture. As believers, how are we to reignite a passion for the Word of God in the world around us?

",
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'01-31-2020');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext, image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
10,
10,
'10.png',
'png',
'https://www.catholicteacherresources.com/bible-stories-daniel-in-the-lions-den/',
'Courage Through Faith in God',
'Josh Rice',
'The overarching issue facing believers continues to be, Will we stubbornly cling to our personal views or will we commit to biblical standards? Will we follow the absolute principles of the Word of God or be tempted to devise our own guidelines as we are influenced by culture?',
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'01-20-2012');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext,image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
11,
11,
'11.png',
'png',
'https://www.istockphoto.com/vector/satan-tempts-jesus-in-the-wilderness-gm1156404083-315146306',
'Questions on Ethics',
'R. Keith Whitt',
"The overarching issue facing believers continues to be, Will we stubbornly cling to our personal views or will we commit to biblical standards? Will we follow the absolute principles of the Word of God or be tempted to devise our own guidelines as we are influenced by culture?",
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'04-20-2022');

INSERT INTO
  contents (id, tag_id, cover_image, image_ext,image_source, title, author, describe, slide_link, activity_link, upload_date)
VALUES (
12,
12,
'12.png',
'png',
'https://www.sabbathschoolpersonalministries.org/assets',
'Rahab, an Unlikely Ally',
'Jerald Daffe',
"Sometimes overlooked are those who do not make a great first impression or haven't received honors and recognition. People with lower-level jobs, limited education, and a minimal range of skills are often bypassed. It is amazing the bias, prejudice, and discrimination which often comes into play.",
'https://docs.google.com/presentation/d/1AQHynHieDS0vnMa_Maua_e2TfrTXwbFey07xRTxn1Zk/edit#slide=id.p',
'https://sundayschoolzone.com/resource-type/coloring/',
'07-05-2012');

CREATE TABLE tags (
  id INTEGER NOT NULL UNIQUE,
  tag_name TEXT,
  PRIMARY KEY(id AUTOINCREMENT)
);

INSERT INTO
  tags (id, tag_name)
VALUES
  (1, 'bible');

INSERT INTO
  tags (id, tag_name)
VALUES
  (2, 'story');


INSERT INTO
  tags (id, tag_name)
VALUES
  (3, 'new-testament');

INSERT INTO
  tags (id, tag_name)
VALUES
  (4, 'old-testament');


CREATE TABLE content_tags (
  id INTEGER NOT NULL UNIQUE,
  content_id INTEGER NOT NULL,
  tag_id INTEGER NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT),
  FOREIGN KEY (content_id) REFERENCES contents(id),
  FOREIGN KEY (tag_id) REFERENCES tags(id)
);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (1, 1, 1);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (2, 1, 2);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (3, 2, 1);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (4, 2, 3);


INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (5, 3, 2);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (6, 3, 4);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (7, 4, 1);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (8, 4, 4);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (9, 5, 3);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (10, 5, 2);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (11, 6, 1);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (12, 6, 2);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (13, 7, 1);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (14, 7, 3);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (15, 8, 4);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (16, 8, 2);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (17, 9, 1);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (18, 9, 4);

INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (19, 10, 1);
INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (20, 10, 2);
INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (21, 11, 1);
INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (22, 11, 2);
INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (23, 12, 1);
INSERT INTO
  content_tags (id, content_id, tag_id)
VALUES
  (24, 12, 2);
