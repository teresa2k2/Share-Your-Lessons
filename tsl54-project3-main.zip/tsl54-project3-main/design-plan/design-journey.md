# Project 3: Design Journey

**For each milestone, complete only the sections that are labeled with that milestone.** Refine all sections before the final submission.

You are graded on your design process. If you later need to update your plan, **do not delete the original plan, rather leave it in place and append your new plan _below_ the original.** Then explain why you are changing your plan. Any time you update your plan, you're documenting your design process!

**Replace ALL _TODOs_ with your work.** (There should be no TODOs in the final submission.)

Be clear and concise in your writing. Bullets points are encouraged.

**Everything, including images, must be visible in _Markdown: Open Preview_.** If it's not visible in the Markdown preview, then we can't grade it. We also can't give you partial credit either. **Please make sure your design journey should is easy to read for the grader;** in Markdown preview the question _and_ answer should have a blank line between them.


## Design Plan (Milestone 1)

**Make the case for your decisions using concepts from class, as well as other design principles, theories, examples, and cases from outside of class (includes the design prerequisite for this course).**

You can use bullet points and lists, or full paragraphs, or a combo, whichever is appropriate. The writing should be solid draft quality.


### Catalog (Milestone 1)
> What will your catalog website be about? (1 sentence)

A website where Sunday School kids can share their lessons with one another. 

### _Consumer_ Audience (Milestone 1)
> Briefly explain your site's _consumer_ audience. Your audience should be specific, but not arbitrarily specific. (1 sentence)
> Justify why this audience is a **cohesive** group. (1-2 sentences)

My site aduience is Chin Sunday School teachers. This is a cohesive audience because many Chin Sunday School teachers are youths in college or high school with busy schedules that do not have much time to plan lessons every week. 


### _Consumer_ Audience Goals (Milestone 1)
> Document your _consumer_ audience's goals for using this catalog website.
> List each goal below. There is no specific number of goals required for this, but you need enough to do the job (Hint: It's more than 1. But probably not more than 3.)
> **Hint:** Users will be able to view all entries in the catalog and insert new entries into the catalog. The audience's goals should probably relate to these activities.

Goal 1: To find relavent lessons

- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - Allow users to be able to view the lessons shared by other teachers. 
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - This makes sense because the users can look through other teachers' lesson plans to take inspriation for their lessons or use it as their lessons. 

Goal 2: To know what the lesson is about at a glace
- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - require users to create titles for each file
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - This makes sense because users will be able to know a general idea of what the lesson is on. 

### _Consumer_ Audience Device (Milestone 1)
> How will your _consumer_ audience access this website? From a narrow (phone) or wide (laptop) device?
> Justify your decision. (1 sentence)

Audience device:  laptop

Laptop makes more sense because teachers usually do not use their phones to create or view slides. 


### _Consumer_ Persona (Milestone 1)
> Use the goals you identified above to develop a persona of your site's _consumer_ audience.
> Your persona must have a name and a face. The face can be a photo of a face or a drawing, etc.
 
 ![justine](justine.jpg)
 
name: Justine 

**Factors that Influence Behavior:**

- workload
- students' age group 

**Goals:**

- To have cohesive lessons to present every week. 

**Obstacles:**

- Not enough time to plan lessons. 

**Desires:**

- To have someone to help out with lesson plannings during busy weeks. 

### _Administrator_ Audience (Milestone 1)
> Briefly explain your site's _administrator_ audience. Your audience should be specific, but not arbitrarily specific. (1 sentence)
> Justify why this audience is a **cohesive** group. (1-2 sentences)

Site audience: Sunday School teachers

This is a cohesive group because Sunday School teachers are the ones who will be sharing their lessons with other sunday school teachers. 


### _Administrator_ Audience Goals (Milestone 1)
> Document your _administrator_ audience's goals for using this catalog website.
> List each goal below. There is no specific number of goals required for this, but you need enough to do the job (Hint: It's more than 1. But probably not more than 3.)
> **Hint:** Users will be able to view all entries in the catalog and insert new entries into the catalog. The audience's goals should probably relate to these activities.


Goal 1: To share their lessons
- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - Allow users to be able to share their lessons with other teachers. 
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - This makes sense because users will be more at ease if they are also able contribute to other teachers' plan. 

Goal 2: To be able edit their mistakes
- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - Allow users to be able to edit their posts after posting.
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - This makes sense because users will be more at ease knowing they are able to fix their mistakes as they see needed. 


### _Administrator_ Persona (Milestone 1)
> Use the goals you identified above to develop a persona of your site's _administrator_ audience.
> Your persona must have a name and a face. The face can be a photo of a face or a drawing, etc.

 ![anna](anna.jpg)

name: Anna

**Factors that Influence Behavior:**

- schedule 

**Goals:**

- to be able to share relavent lessons with other teachers 

**Obstacles:**

- not having a platform to share their lessons. 

**Desires:**

- to help others with Sunday School lesson planning

### Catalog Data (Milestone 1)
> Using your personas, identify the data you need to include in the catalog for your site's audiences.
> Justify why this data aligns with your persona's goals. (1 sentence)

- Title that describes each catalog image. 
  
  This will help Justine know at first glace if the file is relavant to her goals. 

- date uploaded
  
  This will help Justine decide between which lesson may serve her needs better if the lesson tops are pretty similar. 
  
- person who upload the file

  This will help Justine give credits to rightful owners when presenting her lessons and ask for clarifications if needed. 


### Site Design (Milestone 1)
> Design your catalog website to address the goals of your personas.
> Sketch your site's design:
>
> - These are **design** sketches, not _planning_ sketches.
> - Use text in the sketches to help us understand your design.
> - Where the content of the text is unimportant, you may use squiggly lines for text.
> - **Do not label HTML elements or annotate CSS classes.** This is not a planning sketch.
>
> Provide a brief explanation _underneath_ each sketch. (1 sentence)
> **Refer to your persona by name in each explanation.**

  ![home](home.jpg)
  
  The home page will show Justine all the contents. 
  
  ![home2](home2.jpg)
  
  I decided to change the home page filter to radio instead because I think it would make it easier for Justine to know that she can only click one tag to filter. I also decided to add delete button on every image to make the it easier for Anna to rearrange the contents as she pleases. 

 
  ![detail](detail.jpg)
  
  The detail page will give Justine more in-depth description of the lesson. 
  
  ![404](404.jpg)
  
  The 404 page will help Justine check if she enters the URL correctly. 
  
  ![upload](upload.jpg)
  
  The upload page will allow Anna to upload lessons. 
  
  ![login](login.jpg)
   
  The login page will allow Anna to edit the page. 
  
  ![login2](login2.jpg)
   
  I decided to change the login input areas to the left and make the submit button bigger. I decided to make this change because popup login is not very common design so it may confuse Anna when trying to sign in. Having the submit button the same size as the rest of the text area is also a common practice, so I think making this change will make the website feel more familiar to Justine. 
  
  ![logout](logout.jpg)
  
  The login page will allow Anna to logut when necessary. 
  I decided to remove this page and just lead Anna to the homepage when loggging in. I think this change will make it easier for Anna to see the priviledges she has as an admin. 



### Catalog Design Patterns (Milestone 1)
> Explain how you used design patterns in your site's design. (1-2 sentences)

I used repitition to help the user develop familarity with the page and feel more at ease navigating the page. 


## Implementation Plan (Milestone 1, Milestone 2, Milestone 3, Final Submission)

### Database Schema (Milestone 1)
> Plan the structure of your database. You may use words or a picture.
> A bulleted list is probably the simplest way to do this.
> Make sure you include constraints for each field.

Table: contents

CREATE TABLE contents (
  id INTEGER NOT NULL UNIQUE,
  tag_id INTEGER,
  cover_image TEXT NOT NULL,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  describe TEXT NOT NULL,
  slide_link TEXT NOT NULL,
  activity_link TEXT NOT NULL,
  upload_date TEXT NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT) FOREIGN KEY (tag_id) REFERENCES tags(id)
);

Table: tags
CREATE TABLE tags (
  id INTEGER NOT NULL UNIQUE,
  tag_name TEXT,
  PRIMARY KEY(id AUTOINCREMENT)
);

Table: content_tags
CREATE TABLE content_tags (
  id INTEGER NOT NULL UNIQUE,
  content_id INTEGER NOT NULL,
  tag_id INTEGER NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT),
  FOREIGN KEY (content_id) REFERENCES contents(id),
  FOREIGN KEY (tag_id) REFERENCES tags(id)
);

CREATE TABLE users (
  id INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT)
);

CREATE TABLE sessions (
  id INTEGER NOT NULL UNIQUE,
  user_id INTEGER NOT NULL,
  session TEXT NOT NULL UNIQUE,
  last_login TEXT NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT) FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE groups (
  id INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE,
  PRIMARY KEY(id AUTOINCREMENT)
);

CREATE TABLE user_groups (
  id INTEGER NOT NULL UNIQUE,
  user_id INTEGER NOT NULL,
  group_id INTEGER NOT NULL,
  PRIMARY KEY(id AUTOINCREMENT) FOREIGN KEY(group_id) REFERENCES groups(id),
  FOREIGN KEY(user_id) REFERENCES users(id)
);


### Database Query Plan (Milestone 1, Milestone 2, Milestone 3, Final Submission)
> Plan _all_ of your database queries.
> You may use natural language, pseudocode, or SQL.


```
 SELECT DISTINCT
      contents.cover_image AS 'contents.cover_image',
      contents.title AS 'contents.title',
      contents.author AS 'contents.author',
      content_tags.content_id AS 'content_tags.content_id'

      FROM
        contents
        INNER JOIN content_tags ON ( content_tags.content_id = contents.id)
        LEFT OUTER JOIN tags ON (content_tags.tag_id = tags.id) "

I was told I do not need to use join statements for view all page, so I plan to change the database query to:

   SELECT * FROM contents
   
For my details page, I plan to query my database with join statement:

SELECT * FROM contents
       INNER JOIN content_tags ON contents.id = content_tags.content_id
       LEFT OUTER JOIN tags ON tags.id = content_tags.tag_id
       WHERE contents.id = :content_id

SELECT * FROM tags
       INNER JOIN content_tags ON tags.id = content_tags.tag_id
       WHERE content_tags.content_id = :content_id
       
For my tag filtering, I plan to use conditional and join statements:

if tag is empty:
  get all
  } else {
      SELECT * FROM contents
      INNER JOIN content_tags ON contents.id = content_tags.id
      INNER JOIN tags ON content_tags.tag_id = tags.id
      WHERE tags.tag_name = :tag_name
      GROUP BY contents.id

for my delete button I plan to just delete the matching record from the contents and content_tag table

DELETE FROM content_tags
WHERE content_id = :id

DELETE FROM contents
WHERE id = :id

```

## Complete & Polished Website (Final Submission)

### Accessibility Audit (Final Submission)
> Tell us what issues you discovered during your accessibility audit.
> What do you do to improve the accessibility of your site?

I discovered that my images did not have alt so I added alt on all my images. I also decided that the buttons have contrast errors so I decided to make the background lighter background and the text dark black. 

### Self-Reflection (Final Submission)
> Reflect on what you learned during this assignment. How have you improved from Projects 1 and 2?

With this assignment, I learned how to analyze the instructor's code, implement a working code using different type of codes, and debug my code. I think I especially honed in on my debugging skills with this assignment.

> Take some time here to reflect on how much you've learned since you started this class. It's often easy to ignore our own progress. Take a moment and think about your accomplishments in this class. Hopefully you'll recognize that you've accomplished a lot and that you should be very proud of those accomplishments! (1-3 sentences)

Before this class, I only basically knew HTML and CSS, so I was very scared about back-end coding. After this class, I feel like I can learn any coding langauge and apply it whichever website I want to develop. 

### Collaborators (Final Submission)
> List any persons you collaborated with on this project.

N/A

### Reference Resources (Final Submission)
> Please cite any external resources you referenced in the creation of your project.
> (i.e. W3Schools, StackOverflow, Mozilla, etc.)



www.php.net
www.w3schools.com

### Grading: User Accounts (Final Submission)
> The graders will need to log in to your website.
> Please provide the usernames and passwords.

**Administrator User:**

- Username: anna
- Password: monkey

**Consumer User:**

  My website doesn't support consumer log in. 

**Note:** Not all websites will support consumer log in. If your website doesn't, say so.


### Grading: Step-by-Step Instructions (Final Submission)
> Write step-by-step instructions for the graders.
> The project if very hard to grade if we don't understand how your site works.
> For example, you must log in before you can delete.
> For each set of instructions, assume the grader is starting from /

_View all entries:_

1. click on the logo on the nav bar or click the "view all" button.

_View all entries for a tag:_

1. choose a radio box for the tag you wish to view and click the "filter tag" button. 

_View a single entry's details:_

1. navigate to the homepage
2. click on the image you want to know more about. 

_How to insert and upload a new entry:_

1. click on "share my lessons" button.
2. login using username and password
3. write a text in the textbox under "title' 
4. click on the "choose file" button
5. choose a png file less than 10MB
6. write a text in the textbox under "cover image source'
7. select any checkbox from tags
8. write a text in the textbox under "description'
9. write a text in the textbox under "links to slides'
10. write a text in the textbox under "links to activities'
11. write a text in the textbox under "created by'
12. click the "upload" button

_How to delete an entry:_

1. login using username and password
2. navigate to the view all(home) page 
3. click on the "x" button 
